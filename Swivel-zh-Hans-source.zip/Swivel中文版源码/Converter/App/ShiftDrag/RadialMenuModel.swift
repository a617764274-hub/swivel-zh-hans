import ConverterCore
import Foundation

/// What the wheel shows for the files being dragged, and what the cursor is
/// over. It has three rings: formats to convert to, file tools, and file
/// actions. The first two come from `ConversionMenuModel`, so they match the
/// menu bar picker.
@MainActor
final class RadialMenuModel: ObservableObject {
    enum Phase: Equatable {
        /// Shown, but the drag hasn't entered the panel yet, so the files
        /// aren't known.
        case waiting
        case ready
        case unavailable(String)
    }

    /// What a drop on a slice does.
    enum Target {
        case convert(any Converter)
        case action(FileAction)

        var id: String {
            switch self {
            case .convert(let converter): return converter.id
            case .action(let action): return action.id
            }
        }

        var title: String {
            switch self {
            case .convert(let converter): return converter.title
            case .action(let action): return action.title
            }
        }
    }

    struct Slice: Identifiable {
        let id: Int
        let title: String
        let symbol: String?
        /// Set for a single conversion.
        var converter: (any Converter)?
        /// Set for a file action.
        var action: FileAction?
        /// Members of a group ("更多格式", "调整尺寸", "共享"); empty otherwise.
        var members: [Target] = []

        var isGroup: Bool { converter == nil && action == nil }
    }

    let geometry: RadialGeometry
    let registry: ConverterRegistry
    /// Converter ids the user put first (read each time the ring fills).
    let preferred: () -> [String]
    /// Which key opens which ring, for the hint in the middle.
    var ringKeys: () -> RingKeys = { .standard }
    /// The file actions that work for the dragged files on this Mac.
    var availableActions: ([URL]) -> [FileAction] = { FileAction.available(for: $0) }
    /// Drives the appear and disappear animation.
    @Published var isPresented = false
    @Published private(set) var phase: Phase = .waiting
    @Published private(set) var mode: RingMode = .formats
    @Published private(set) var hit: RadialGeometry.Hit = .outside
    /// Index of the group slice whose sub-ring is open.
    @Published private(set) var openGroup: Int?
    private(set) var inputs: [InputFile] = []
    private var rings: [RingMode: [Slice]] = [:]

    init(geometry: RadialGeometry = RadialGeometry(), registry: ConverterRegistry = .standard,
         preferred: @escaping () -> [String] = { [] }) {
        self.geometry = geometry
        self.registry = registry
        self.preferred = preferred
    }

    /// The slices of the ring on show.
    var slices: [Slice] { rings[mode] ?? [] }

    func reset(mode: RingMode = .formats) {
        phase = .waiting
        rings = [:]
        inputs = []
        self.mode = mode
        hit = .outside
        openGroup = nil
    }

    /// Shows another ring; keeps the loaded files.
    func setMode(_ mode: RingMode) {
        guard mode != self.mode else { return }
        self.mode = mode
        hit = .outside
        openGroup = nil
    }

    /// Fills all three rings for the dragged files.
    func load(_ urls: [URL]) {
        let inputs = urls.compactMap { try? InputFile(url: $0) }
        self.inputs = inputs
        hit = .outside
        openGroup = nil
        guard !inputs.isEmpty else {
            rings = [:]
            phase = .unavailable("没有可处理的文件")
            return
        }
        let menu = ConversionMenuModel(converters: registry.converters(for: inputs), preferred: preferred())
        rings[.formats] = Self.slices(from: menu.formats)
        rings[.tools] = Self.slices(from: menu.tools)
        rings[.actions] = Self.slices(from: availableActions(inputs.map(\.url)))
        phase = .ready
    }

    private static func slices(from entries: [ConversionMenuModel.Entry]) -> [Slice] {
        entries.enumerated().map { index, entry in
            switch entry {
            case .converter(let converter):
                return Slice(id: index, title: converter.title, symbol: symbol(for: converter), converter: converter)
            case .group(let title, let members):
                // Slices are narrow: the menu bar's "更多格式" is just "更多" here.
                let short = title == ConversionMenuModel.moreFormatsTitle ? "更多" : title
                return Slice(id: index, title: short, symbol: symbol(forGroup: title), members: members.map(Target.convert))
            }
        }
    }

    /// One slice per action, with grouped actions ("共享") in a sub-ring.
    private static func slices(from actions: [FileAction]) -> [Slice] {
        var slices: [Slice] = []
        for action in actions {
            guard let group = action.group else {
                slices.append(Slice(id: slices.count, title: action.title, symbol: action.symbol, action: action))
                continue
            }
            if let index = slices.firstIndex(where: { $0.isGroup && $0.title == group }) {
                slices[index].members.append(.action(action))
            } else {
                slices.append(Slice(id: slices.count, title: group, symbol: symbol(forGroup: group), members: [.action(action)]))
            }
        }
        return slices
    }

    var openGroupMembers: [Target] {
        openGroup.map { slices[$0].members } ?? []
    }

    /// Updates what's under the cursor (y-up point relative to the centre).
    /// Returns the group slice to open after a short dwell, if the cursor
    /// just moved onto one.
    @discardableResult
    func hover(at point: CGPoint) -> Int? {
        let open = openGroup.map { (parent: $0, members: slices[$0].members.count) }
        let newHit = geometry.hit(point, count: phase == .ready ? slices.count : 0, openGroup: open)
        defer { hit = newHit }
        switch newHit {
        case .slice(let index):
            if index != openGroup { openGroup = nil }
            return slices[index].isGroup && index != openGroup && newHit != hit ? index : nil
        case .center:
            openGroup = nil
            return nil
        case .subSlice, .outside:
            return nil
        }
    }

    func openGroup(_ index: Int) {
        guard slices.indices.contains(index), slices[index].isGroup, hit == .slice(index) else { return }
        openGroup = index
    }

    func clearHover() {
        hit = .outside
    }

    /// What a drop at the current position would do; nil means it cancels.
    var target: Target? {
        switch hit {
        case .slice(let index):
            guard slices.indices.contains(index) else { return nil }
            if let converter = slices[index].converter { return .convert(converter) }
            return slices[index].action.map(Target.action)
        case .subSlice(let index):
            let members = openGroupMembers
            return members.indices.contains(index) ? members[index] : nil
        case .center, .outside:
            return nil
        }
    }

    /// Text for the middle of the ring.
    var caption: (title: String, detail: String?) {
        switch phase {
        case .waiting:
            return (mode.title, nil)
        case .unavailable(let message):
            return (message, nil)
        case .ready:
            if hit == .center { return ("取消", nil) }
            if slices.isEmpty { return (emptyMessage, "滚动查看更多") }
            switch target {
            case .convert(let converter):
                return (converter.title, OutputPreview.name(of: converter, for: inputs) ?? "\(inputs.count) 个文件")
            case .action(let action):
                let title = action == .shareMore ? "共享…" : action.title
                return (title, inputs.count == 1 ? inputs[0].url.lastPathComponent : "\(inputs.count) 个项目")
            case nil:
                if case .slice(let index) = hit, slices[index].isGroup { return (slices[index].title, nil) }
                return (inputs.count == 1 ? inputs[0].url.lastPathComponent : "\(inputs.count) 个项目", nil)
            }
        }
    }

    private var emptyMessage: String {
        switch mode {
        case .formats: return inputs.count == 1 ? "没有可用格式" : "没有共同格式"
        case .tools: return inputs.count == 1 ? "没有可用工具" : "没有共同工具"
        case .actions: return "没有可用操作"
        }
    }

    private static func symbol(for converter: any Converter) -> String? {
        switch converter.id {
        case "image.compress", "video.compress", "audio.compress", "pdf.compress": return "arrow.down.right.and.arrow.up.left"
        case "image.stripMetadata", "video.stripMetadata", "pdf.stripMetadata": return "eye.slash"
        case let id where id.hasPrefix("image.crop."): return "crop"
        case "image.rotate.left": return "rotate.left"
        case "image.rotate.right": return "rotate.right"
        case "image.rotate.180": return "arrow.clockwise"
        case "image.flip.horizontal": return "arrow.left.and.right.righttriangle.left.righttriangle.right"
        case "image.flip.vertical": return "arrow.up.and.down.righttriangle.up.righttriangle.down"
        case let id where id.hasPrefix("image.fit."): return "scalemass"
        // A macOS 14 symbol, like the tool itself.
        case "image.removeBackground": return "person.and.background.dotted"
        case "ocr.text": return "text.viewfinder"
        case "video.removeAudio": return "speaker.slash"
        case "pdf.split", "pdf.merge", "image.combinePDF": return "doc.on.doc"
        case "image.pdf", "document.pdf": return "doc"
        case "archive.extract": return "archivebox"
        case "video.frame": return "camera"
        case let id where id.hasPrefix("image.video."): return "film"
        default: return nil
        }
    }

    private static func symbol(forGroup title: String) -> String? {
        switch title {
        case "调整尺寸": return "arrow.up.left.and.arrow.down.right"
        case "裁剪": return "crop"
        case "旋转": return "rotate.right"
        case "限制文件大小": return "scalemass"
        case FileAction.shareGroup: return "square.and.arrow.up"
        case "音频": return "waveform"
        case "归档": return "archivebox"
        default: return "ellipsis"
        }
    }
}
