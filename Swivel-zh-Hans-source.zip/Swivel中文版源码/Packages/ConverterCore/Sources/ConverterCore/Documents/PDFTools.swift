import CoreGraphics
import Foundation
import ImageIO
import PDFKit
import Vision

/// Files in Finder-like name order ("2" before "10"), so merged pages follow
/// the names rather than the order the files happened to be dragged in.
func inNameOrder(_ inputs: [InputFile]) -> [InputFile] {
    inputs.sorted { $0.url.lastPathComponent.localizedStandardCompare($1.url.lastPathComponent) == .orderedAscending }
}

// MARK: - Merge

/// Two or more PDFs → one, in name order, named after the first.
public struct MergePDFsConverter: Converter {
    public init() {}

    public var id: String { "pdf.merge" }
    public var title: String { "合并 PDF" }
    public var role: ConverterRole { .tool }
    public var combinesInputs: Bool { true }
    public var minimumInputs: Int { 2 }
    public var isAvailable: Bool { true }

    public func accepts(_ input: InputFile) -> Bool {
        PDFFiles.isPDF(input)
    }

    public func output(for input: InputFile) -> OutputSpec {
        OutputSpec(fileExtension: "pdf", nameSuffix: "（已合并）")
    }

    public func output(for inputs: [InputFile]) -> OutputSpec {
        OutputSpec(fileExtension: "pdf", nameSuffix: "（已合并）", baseName: inNameOrder(inputs).first?.baseName)
    }

    public func convert(_ input: InputFile, to destination: URL, options: ConversionOptions, progress: ProgressHandler) async throws {
        throw ConversionError.nothingToDo("请选择至少两个 PDF 进行合并。")
    }

    public func convert(_ inputs: [InputFile], to destination: URL, options: ConversionOptions, progress: ProgressHandler) async throws {
        guard inputs.count >= minimumInputs else { throw ConversionError.nothingToDo("请选择至少两个 PDF 进行合并。") }
        let merged = PDFDocument()
        let ordered = inNameOrder(inputs)
        for (index, input) in ordered.enumerated() {
            try Task.checkCancellation()
            let document = try PDFFiles.open(input)
            for page in 0..<document.pageCount {
                // A page can only belong to one document.
                guard let copy = document.page(at: page)?.copy() as? PDFPage else { continue }
                merged.insert(copy, at: merged.pageCount)
            }
            progress(Double(index + 1) / Double(ordered.count) * 0.9)
        }
        guard merged.write(to: destination) else { throw ConversionError.encoderFailed("无法写入合并后的 PDF") }
    }
}

// MARK: - Split

/// A PDF of several pages → a folder with one PDF per page.
public struct SplitPDFConverter: Converter {
    public init() {}

    public var id: String { "pdf.split" }
    public var title: String { "拆分页面" }
    public var role: ConverterRole { .tool }
    public var isAvailable: Bool { true }

    public func accepts(_ input: InputFile) -> Bool {
        PDFFiles.isPDF(input) && PDFFiles.pageCount(input.url) > 1
    }

    public func output(for input: InputFile) -> OutputSpec {
        OutputSpec(fileExtension: "", nameSuffix: "（已拆分）", isDirectory: true)
    }

    public func convert(_ input: InputFile, to destination: URL, options: ConversionOptions, progress: ProgressHandler) async throws {
        let document = try PDFFiles.open(input)
        let count = document.pageCount
        guard count > 1 else { throw ConversionError.nothingToDo("\(input.url.lastPathComponent)仅有一页。") }
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: false)
        let digits = String(count).count
        for index in 0..<count {
            try Task.checkCancellation()
            guard let copy = document.page(at: index)?.copy() as? PDFPage else { continue }
            let single = PDFDocument()
            single.insert(copy, at: 0)
            let number = String(index + 1)
            let name = "\(input.baseName) \(String(repeating: "0", count: digits - number.count))\(number).pdf"
            guard single.write(to: destination.appendingPathComponent(name)) else {
                throw ConversionError.encoderFailed("无法写入第 \(index + 1) 页")
            }
            progress(Double(index + 1) / Double(count) * 0.95)
        }
    }
}

// MARK: - Compress

/// Rewrites a PDF with its images as JPEG at screen resolution (PDFKit,
/// macOS 13.4 and later). Text-only PDFs rarely shrink, so a result that
/// isn't smaller is reported instead of saved.
public struct CompressPDFConverter: Converter {
    public init() {}

    public var id: String { "pdf.compress" }
    public var title: String { "压缩" }
    public var role: ConverterRole { .tool }

    public var isAvailable: Bool {
        if #available(macOS 13.4, *) { return true }
        return false
    }

    public func accepts(_ input: InputFile) -> Bool {
        PDFFiles.isPDF(input)
    }

    public func output(for input: InputFile) -> OutputSpec {
        OutputSpec(fileExtension: "pdf", nameSuffix: "（已压缩）")
    }

    public func convert(_ input: InputFile, to destination: URL, options: ConversionOptions, progress: ProgressHandler) async throws {
        guard #available(macOS 13.4, *) else { throw ConversionError.unsupported("压缩 PDF 需要 macOS 13.4 或更高版本。") }
        let document = try PDFFiles.open(input)
        let written = document.write(to: destination, withOptions: [
            .saveImagesAsJPEGOption: true,
            .optimizeImagesForScreenOption: true,
        ])
        guard written else { throw ConversionError.encoderFailed("无法写入压缩后的 PDF") }
        let before = (try? input.url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        let after = (try? destination.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        if before > 0 && after >= before * 95 / 100 {
            throw ConversionError.nothingToDo("\(input.url.lastPathComponent)的可压缩空间很小，处理后文件并未变小。")
        }
    }
}

// MARK: - Remove metadata

/// Rewrites a PDF without its document information: title, author, subject,
/// keywords, the application that made it and its dates; and without who
/// wrote each annotation and when it last changed. The pages and the
/// annotations themselves aren't changed. (PDFKit records itself as the
/// producer of the copy.)
public struct RemovePDFMetadataConverter: Converter {
    public init() {}

    public var id: String { "pdf.stripMetadata" }
    public var title: String { "移除元数据" }
    public var role: ConverterRole { .tool }
    public var isAvailable: Bool { true }

    public func accepts(_ input: InputFile) -> Bool {
        PDFFiles.isPDF(input)
    }

    public func output(for input: InputFile) -> OutputSpec {
        OutputSpec(fileExtension: "pdf", nameSuffix: "（无元数据）")
    }

    public func convert(_ input: InputFile, to destination: URL, options: ConversionOptions, progress: ProgressHandler) async throws {
        let document = try PDFFiles.open(input)
        document.documentAttributes = [:]
        for index in 0..<document.pageCount {
            try Task.checkCancellation()
            // A note or highlight records its author ("T") and date ("M").
            for annotation in document.page(at: index)?.annotations ?? [] {
                annotation.removeValue(forAnnotationKey: .textLabel)
                annotation.removeValue(forAnnotationKey: .date)
            }
        }
        guard document.write(to: destination) else { throw ConversionError.encoderFailed("无法写入 PDF") }
    }
}

// MARK: - Combine images

/// Two or more images → one PDF, a page per image in name order, each page
/// sized from the image's resolution (DPI).
public struct CombineImagesToPDFConverter: Converter {
    public init() {}

    public var id: String { "image.combinePDF" }
    public var title: String { "合成为 PDF" }
    public var role: ConverterRole { .tool }
    public var combinesInputs: Bool { true }
    public var minimumInputs: Int { 2 }
    public var isAvailable: Bool { true }

    public func accepts(_ input: InputFile) -> Bool {
        input.image != nil
    }

    public func output(for input: InputFile) -> OutputSpec {
        OutputSpec(fileExtension: "pdf", nameSuffix: "（已合成）")
    }

    public func output(for inputs: [InputFile]) -> OutputSpec {
        OutputSpec(fileExtension: "pdf", nameSuffix: "（已合成）", baseName: inNameOrder(inputs).first?.baseName)
    }

    public func convert(_ input: InputFile, to destination: URL, options: ConversionOptions, progress: ProgressHandler) async throws {
        throw ConversionError.nothingToDo("请选择至少两张图像进行合成。")
    }

    public func convert(_ inputs: [InputFile], to destination: URL, options: ConversionOptions, progress: ProgressHandler) async throws {
        guard let context = CGContext(destination as CFURL, mediaBox: nil, [kCGPDFContextCreator: "Converter"] as CFDictionary) else {
            throw ConversionError.encoderFailed("无法创建 PDF")
        }
        let ordered = inNameOrder(inputs)
        for (index, input) in ordered.enumerated() {
            try Task.checkCancellation()
            guard let info = input.image else { throw ConversionError.unreadableInput(input.url) }
            let source = try ImageCodec.openSource(input)
            let image = try ImageCodec.decode(source, index: info.primaryIndex)
            let props = ImageCodec.properties(source, info.primaryIndex)
            let dpiX = (props[kCGImagePropertyDPIWidth] as? NSNumber)?.doubleValue ?? 72
            let dpiY = (props[kCGImagePropertyDPIHeight] as? NSNumber)?.doubleValue ?? 72
            var box = CGRect(x: 0, y: 0, width: Double(image.width) * 72 / (dpiX > 0 ? dpiX : 72),
                             height: Double(image.height) * 72 / (dpiY > 0 ? dpiY : 72))
            context.beginPage(mediaBox: &box)
            context.interpolationQuality = .high
            context.draw(image, in: box)
            context.endPage()
            progress(Double(index + 1) / Double(ordered.count) * 0.95)
        }
        context.closePDF()
    }
}

// MARK: - Recognize text (OCR)

/// Image or PDF → plain text, recognised on this Mac with Vision. Nothing
/// leaves the computer.
public struct RecognizeTextConverter: Converter {
    public init() {}

    public var id: String { "ocr.text" }
    public var title: String { "识别文字" }
    public var role: ConverterRole { .tool }
    public var isAvailable: Bool { true }

    public func accepts(_ input: InputFile) -> Bool {
        input.image != nil || PDFFiles.isPDF(input)
    }

    public func output(for input: InputFile) -> OutputSpec {
        OutputSpec(fileExtension: "txt", nameSuffix: "（文字）")
    }

    public func convert(_ input: InputFile, to destination: URL, options: ConversionOptions, progress: ProgressHandler) async throws {
        var pages: [String] = []
        if let info = input.image {
            let source = try ImageCodec.openSource(input)
            pages = [try Self.recognize(ImageCodec.decode(source, index: info.primaryIndex))]
        } else {
            guard let document = CGPDFDocument(input.url as CFURL) else { throw ConversionError.unreadableInput(input.url) }
            for number in 1...max(document.numberOfPages, 1) {
                try Task.checkCancellation()
                guard let page = document.page(at: number) else { continue }
                pages.append(try Self.recognize(PDFToImagesConverter.render(page, dpi: 200, opaque: true)))
                progress(Double(number) / Double(document.numberOfPages) * 0.95)
            }
        }
        let text = pages.joined(separator: "\n\u{0C}\n")
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw ConversionError.nothingToDo("在\(input.url.lastPathComponent)中未找到文字。")
        }
        try Data(text.utf8).write(to: destination)
    }

    /// Lines of text, top to bottom.
    static func recognize(_ image: CGImage) throws -> String {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        request.automaticallyDetectsLanguage = true
        try VNImageRequestHandler(cgImage: image).perform([request])
        let observations = (request.results ?? []).sorted {
            // Vision's origin is bottom-left: higher lines first, then left to right.
            abs($0.boundingBox.midY - $1.boundingBox.midY) > 0.01
                ? $0.boundingBox.midY > $1.boundingBox.midY
                : $0.boundingBox.minX < $1.boundingBox.minX
        }
        return observations.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
    }
}

extension PDFFiles {
    static func open(_ input: InputFile) throws -> PDFDocument {
        guard let document = PDFDocument(url: input.url) else { throw ConversionError.unreadableInput(input.url) }
        if document.isLocked { throw ConversionError.unsupported("\(input.url.lastPathComponent)受密码保护。") }
        return document
    }
}
