import ConverterCore
import Darwin
import Foundation

/// The `swivel` command: ConverterCore's conversions without the app.
@main
struct CLI {
    /// Kept in step with MARKETING_VERSION in Converter/project.yml (`make release` checks).
    static let version = "1.0.0"

    static let usage = """
    用法：swivel formats
           swivel list <文件>...
           swivel convert --to <标识> [--quality 0-1] [--compression-quality 0-1] [--no-metadata] <文件>...
           swivel --version

      formats   列出所有转换方式及此 Mac 的支持情况
      list      列出所选文件的可用转换方式
      convert   逐个转换文件；结果保存在原文件旁，不覆盖原文件

    转换时按 Ctrl-C 取消，不保留未完成的文件。
    """

    static func main() async {
        var args = Array(CommandLine.arguments.dropFirst())
        guard let command = args.first else { fail(usage, code: 2) }
        args.removeFirst()

        switch command {
        case "formats": printFormats()
        case "list": listConversions(for: args)
        case "convert": exit(await convert(args))
        case "-h", "--help", "help": print(usage)
        case "-v", "--version", "version": print("swivel \(version)")
        default: fail("未知命令 '\(command)'\n\n\(usage)", code: 2)
        }
    }

    static func printFormats() {
        for converter in ConverterRegistry.standard.everything {
            let status = converter.isAvailable ? "" : "  （此 Mac 不支持）"
            print("\(converter.id.padding(toLength: 22, withPad: " ", startingAt: 0)) \(converter.title)\(status)")
        }
    }

    static func listConversions(for paths: [String]) {
        guard !paths.isEmpty else { fail(usage, code: 2) }
        let inputs = paths.map(loadInput)
        let converters = ConverterRegistry.standard.converters(for: inputs)
        if converters.isEmpty {
            print("没有可用的转换方式：\(paths.count == 1 ? "此文件" : "所有这些文件").")
        }
        for role in [ConverterRole.format, .tool] {
            let group = converters.filter { $0.role == role }
            guard !group.isEmpty else { continue }
            print(role == .format ? "格式：" : "工具：")
            for converter in group {
                let example = inputs[0]
                let spec = converter.combinesInputs ? converter.output(for: inputs) : converter.output(for: example)
                let name = OutputNamer.name(base: spec.baseName ?? example.baseName, suffix: spec.nameSuffix,
                                            fileExtension: spec.fileExtension, attempt: 1)
                let marker = converter.isSecondary ? "（更多）" : ""
                print("  \(converter.id.padding(toLength: 22, withPad: " ", startingAt: 0)) \(converter.title)\(marker)  → \(name)")
            }
        }
    }

    static func convert(_ arguments: [String]) async -> Int32 {
        var args = arguments
        var options = ConversionOptions()
        var converterID: String?
        var paths: [String] = []
        while !args.isEmpty {
            let arg = args.removeFirst()
            switch arg {
            case "--to": converterID = args.isEmpty ? nil : args.removeFirst()
            case "--quality": options.imageQuality = parseFraction(args.isEmpty ? "" : args.removeFirst())
            case "--compression-quality": options.compressionQuality = parseFraction(args.isEmpty ? "" : args.removeFirst())
            case "--no-metadata": options.keepMetadata = false
            default:
                if arg.hasPrefix("--") { fail("未知选项 '\(arg)'", code: 2) }
                paths.append(arg)
            }
        }
        guard let converterID, !paths.isEmpty else { fail(usage, code: 2) }
        guard let converter = ConverterRegistry.standard.converter(id: converterID) else {
            fail("未知转换方式 '\(converterID)'。运行 swivel formats 查看全部转换方式。", code: 2)
        }
        let inputs = paths.map(loadInput)

        let showProgress = isatty(STDERR_FILENO) != 0
        let job = Task {
            await JobRunner.run(converter, on: inputs, options: options) { fraction in
                guard showProgress else { return }
                let percent = Int((fraction * 100).rounded())
                FileHandle.standardError.write(Data("\r\(converter.title): \(percent)%  ".utf8))
            }
        }
        // Ctrl-C cancels the job instead of killing the process mid-write.
        signal(SIGINT, SIG_IGN)
        let interrupt = DispatchSource.makeSignalSource(signal: SIGINT, queue: .global())
        interrupt.setEventHandler { job.cancel() }
        interrupt.resume()

        let results = await job.value
        interrupt.cancel()
        if showProgress { FileHandle.standardError.write(Data("\r\u{1B}[K".utf8)) }

        var failed = false
        var cancelled = false
        // A combining converter (archives) returns one result for all inputs.
        let labels = results.count == inputs.count
            ? inputs.map(\.url.lastPathComponent)
            : ["\(inputs.count) 个文件"]
        for (label, result) in zip(labels, results) {
            switch result {
            case .success(let url):
                print("\(label) → \(url.lastPathComponent)")
            case .failure(let error) where error is CancellationError:
                cancelled = true
                print("\(label): 已取消")
            case .failure(let error):
                failed = true
                print("\(label): \(error.localizedDescription)")
            }
        }
        return cancelled ? 130 : (failed ? 1 : 0)
    }

    static func loadInput(_ path: String) -> InputFile {
        do {
            return try InputFile(url: URL(fileURLWithPath: path))
        } catch {
            fail(error.localizedDescription, code: 1)
        }
    }

    static func parseFraction(_ text: String) -> Double {
        guard let value = Double(text), (0...1).contains(value) else {
            fail("质量必须是 0 到 1 之间的数字", code: 2)
        }
        return value
    }

    static func fail(_ message: String, code: Int32) -> Never {
        FileHandle.standardError.write(Data((message + "\n").utf8))
        exit(code)
    }
}
