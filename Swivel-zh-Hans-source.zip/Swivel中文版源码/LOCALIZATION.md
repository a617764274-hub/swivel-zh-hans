# 作者与中文本地化

- 原软件作者：Jonathan Lotan。
- 原项目：https://github.com/jonathanlotan/Swivel
- 本地化基础版本：v1.0.0。
- 简体中文本地化：Ethan（GitHub：a617764274-hub），使用 AI 工具辅助完成。

这是非官方简体中文本地化副本，不代表原作者发行、认可或提供支持。原软件版权归 Jonathan Lotan 所有。本地化未修改上游仓库或官方发行包。

沿用上游 MIT 许可证，并完整保留其版权声明、许可条款及免责条款。分享或再分发时，请一并保留这些文件。
